# Project structure

```text
clinfact_safesum_hf_code/
├── run_all.py                         # Proposed method plus four baselines
├── run_proposed.py                    # Proposed method only
├── run_baseline_raw_phi3.py           # Baseline 1
├── run_baseline_raw_llama.py          # Baseline 2
├── run_baseline_prompt_llama.py       # Baseline 3
├── run_baseline_rag_llama.py          # Baseline 4
├── run_common.py                      # Shared command line arguments
├── requirements.txt
├── data/sample.jsonl
└── clinfact/
    ├── config.py
    ├── models/hf_generator.py
    ├── core/prompts.py                # All prompts
    ├── core/fact_extraction.py
    ├── core/generation.py
    ├── core/claim_processing.py
    ├── core/verification.py
    ├── core/omission.py
    ├── core/correction.py
    ├── core/deterministic_audit.py
    ├── core/safety.py
    ├── proposed/clinfact_safesum.py
    ├── baselines/raw_phi3.py
    ├── baselines/raw_llama8b.py
    ├── baselines/prompt_llama.py
    ├── baselines/rag_llama.py
    └── evaluation/
```

## Baselines

1. Raw Phi 3 mini 128k instruct
2. Raw Llama 8B
3. Prompt based Llama
4. Retrieval augmented Llama

## Proposed pipeline

1. Extract atomic source facts
2. Classify required facts
3. Generate 5 candidate summaries with Phi 3 mini
4. Select best candidate using coverage and hallucination score
5. Decompose selected summary into atomic claims
6. Retrieve source evidence
7. Verify each claim as supported, contradicted, unsupported, or unclear
8. Detect missing or partially covered required facts
9. Recover omission candidates and verify them against source
10. Run deterministic numeric, medication, and negation audit
11. Correct unsafe summary
12. Repeat verification and correction up to Rmax
13. Assign pass, abstain, or fail safety gate decision
14. Deliver only pass summaries
```
