import argparse
import gc
from tqdm import tqdm
from run_common import add_common_args, build_configs
from clinfact.baselines.prompt_llama import PromptLlamaBaseline
from clinfact.baselines.rag_llama import RAGLlamaBaseline
from clinfact.baselines.raw_llama8b import RawLlama8BBaseline
from clinfact.baselines.raw_phi3 import RawPhi3Baseline
from clinfact.core.data import load_documents
from clinfact.evaluation.metrics import aggregate_by_method
from clinfact.evaluation.offline_safety_eval import OfflineSafetyEvaluator
from clinfact.proposed.clinfact_safesum import ClinFactSafeSum
from clinfact.utils.io import ensure_dir, write_json, write_jsonl


def release_memory():
    gc.collect()
    try:
        import torch
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    except Exception:
        pass


def run_system(name, system, docs):
    rows = []
    for doc in tqdm(docs, desc=name):
        rows.append(system.run_one(doc))
    return rows


def main():
    parser = argparse.ArgumentParser(description="Run proposed ClinFact SafeSum and all baselines sequentially.")
    add_common_args(parser)
    parser.add_argument("--audit_baselines", action="store_true", help="Audit baseline summaries with the source grounded verifier. This is slower.")
    args = parser.parse_args()

    out = ensure_dir(args.out)
    model_config, pipeline_config = build_configs(args)
    docs = load_documents(args.data)
    all_predictions = []

    runs = [
        ("ClinFact SafeSum", ClinFactSafeSum, "proposed_predictions.jsonl"),
        ("Raw Phi 3", RawPhi3Baseline, "baseline_raw_phi3_predictions.jsonl"),
        ("Raw Llama 8B", RawLlama8BBaseline, "baseline_raw_llama_predictions.jsonl"),
        ("Prompt Llama", PromptLlamaBaseline, "baseline_prompt_llama_predictions.jsonl"),
        ("RAG Llama", RAGLlamaBaseline, "baseline_rag_llama_predictions.jsonl"),
    ]

    for name, cls, filename in runs:
        system = cls(model_config, pipeline_config)
        rows = run_system(name, system, docs)
        write_jsonl(out / filename, rows)
        all_predictions.extend(rows)
        del system
        release_memory()

    if args.audit_baselines:
        baseline_rows = [p for p in all_predictions if p.get("method") != "ClinFact SafeSum"]
        evaluator = OfflineSafetyEvaluator(model_config, pipeline_config)
        doc_map = {d.doc_id: d for d in docs}
        for row in tqdm(baseline_rows, desc="Offline audit baselines"):
            doc = doc_map[row["doc_id"]]
            row["offline_safety_audit"] = evaluator.audit(doc, row.get("summary", ""))
        del evaluator
        release_memory()

    write_jsonl(out / "all_predictions.jsonl", all_predictions)
    metrics = aggregate_by_method(all_predictions, compute_bert=args.compute_bert)
    write_json(out / "all_metrics_by_method.json", metrics)
    print(f"Saved all outputs to {out}")


if __name__ == "__main__":
    main()
