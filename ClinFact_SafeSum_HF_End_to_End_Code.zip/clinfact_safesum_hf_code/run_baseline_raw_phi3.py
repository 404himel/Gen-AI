import argparse
from tqdm import tqdm
from run_common import add_common_args, build_configs
from clinfact.baselines.raw_phi3 import RawPhi3Baseline
from clinfact.core.data import load_documents
from clinfact.evaluation.metrics import evaluate_predictions
from clinfact.utils.io import ensure_dir, write_json, write_jsonl


def main():
    parser = argparse.ArgumentParser(description="Run raw Phi 3 baseline.")
    add_common_args(parser)
    args = parser.parse_args()
    out = ensure_dir(args.out)
    model_config, pipeline_config = build_configs(args)
    docs = load_documents(args.data)
    system = RawPhi3Baseline(model_config, pipeline_config)
    predictions = [system.run_one(doc) for doc in tqdm(docs, desc="Raw Phi 3")]
    write_jsonl(out / "baseline_raw_phi3_predictions.jsonl", predictions)
    write_json(out / "baseline_raw_phi3_metrics.json", evaluate_predictions(predictions, compute_bert=args.compute_bert))
    print(f"Saved raw Phi 3 outputs to {out}")


if __name__ == "__main__":
    main()
