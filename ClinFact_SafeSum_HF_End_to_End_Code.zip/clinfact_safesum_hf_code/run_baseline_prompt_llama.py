import argparse
from tqdm import tqdm
from run_common import add_common_args, build_configs
from clinfact.baselines.prompt_llama import PromptLlamaBaseline
from clinfact.core.data import load_documents
from clinfact.evaluation.metrics import evaluate_predictions
from clinfact.utils.io import ensure_dir, write_json, write_jsonl


def main():
    parser = argparse.ArgumentParser(description="Run prompt based Llama baseline.")
    add_common_args(parser)
    args = parser.parse_args()
    out = ensure_dir(args.out)
    model_config, pipeline_config = build_configs(args)
    docs = load_documents(args.data)
    system = PromptLlamaBaseline(model_config, pipeline_config)
    predictions = [system.run_one(doc) for doc in tqdm(docs, desc="Prompt Llama")]
    write_jsonl(out / "baseline_prompt_llama_predictions.jsonl", predictions)
    write_json(out / "baseline_prompt_llama_metrics.json", evaluate_predictions(predictions, compute_bert=args.compute_bert))
    print(f"Saved prompt Llama outputs to {out}")


if __name__ == "__main__":
    main()
