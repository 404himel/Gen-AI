# ClinFact SafeSum HF Code

This repository contains an end to end Hugging Face implementation of the ClinFact SafeSum pipeline and four baseline systems.

## What is included

- Proposed method: `ClinFactSafeSum`
- Baseline 1: raw Phi 3 mini 128k instruct
- Baseline 2: raw Llama 8B instruct
- Baseline 3: prompt based Llama 8B instruct
- Baseline 4: retrieval augmented Llama 8B instruct
- Shared prompts for fact extraction, summary generation, claim verification, omission recovery, correction, and safety reporting
- JSONL or CSV dataset loading
- Rouge and optional BERTScore evaluation
- Safety report generation
- Mock mode for quick syntax and pipeline testing without downloading models

## Dataset format

Use either JSONL or CSV.

Required columns or keys:

```json
{"id":"doc001", "source":"clinical note text here", "reference":"optional reference summary"}
```

The `reference` field is optional. If it is missing, the pipeline still runs safety and factuality analysis, but ROUGE and BERTScore are skipped.

## Install

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

For Windows PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

## Hugging Face access

Phi 3 mini usually downloads directly from Hugging Face.

Meta Llama 8B models are gated on Hugging Face. You need to request access and login:

```bash
huggingface-cli login
```

or set:

```bash
export HF_TOKEN=your_token
```

On Windows PowerShell:

```powershell
$env:HF_TOKEN="your_token"
```

## Quick smoke test without downloading models

```bash
python run_all.py --data data/sample.jsonl --out outputs/mock_run --mock
```

## Run proposed method only

```bash
python run_proposed.py --data data/sample.jsonl --out outputs/proposed_real
```

## Run all systems with HF models

```bash
python run_all.py --data data/sample.jsonl --out outputs/full_run
```

## Default model IDs

```text
Proposed generation model: microsoft/Phi-3-mini-128k-instruct
Raw Phi baseline: microsoft/Phi-3-mini-128k-instruct
Llama baselines: meta-llama/Meta-Llama-3.1-8B-Instruct
```

You can override model IDs from the command line.

## Important limitation

This code implements an automatic source grounded research pipeline. It is not a clinical deployment system. If you do not use clinician annotated labels, do not report verifier precision, recall, F1, macro F1, or Cohen kappa as human validated verifier metrics.
