import argparse
from tqdm import tqdm
from run_common import add_common_args, build_configs
from clinfact.core.data import load_documents
from clinfact.evaluation.metrics import evaluate_predictions
from clinfact.proposed.clinfact_safesum import ClinFactSafeSum
from clinfact.utils.io import ensure_dir, write_json, write_jsonl


def main():
    parser = argparse.ArgumentParser(description="Run proposed ClinFact SafeSum pipeline.")
    add_common_args(parser)
    args = parser.parse_args()
    out = ensure_dir(args.out)
    model_config, pipeline_config = build_configs(args)
    docs = load_documents(args.data)
    system = ClinFactSafeSum(model_config, pipeline_config)
    predictions = []
    for doc in tqdm(docs, desc="ClinFact SafeSum"):
        predictions.append(system.run_one(doc))
    write_jsonl(out / "proposed_predictions.jsonl", predictions)
    write_json(out / "proposed_metrics.json", evaluate_predictions(predictions, compute_bert=args.compute_bert))
    print(f"Saved proposed outputs to {out}")


if __name__ == "__main__":
    main()
