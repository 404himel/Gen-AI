from dataclasses import asdict
from typing import Any, Dict, List

from clinfact.config import ModelConfig, PipelineConfig
from clinfact.core.claim_processing import ClaimDecomposer
from clinfact.core.correction import Corrector
from clinfact.core.deterministic_audit import deterministic_audit
from clinfact.core.fact_extraction import FactExtractor, required_facts
from clinfact.core.generation import CandidateGenerator
from clinfact.core.omission import OmissionRecoverer, candidate_omissions, required_fact_coverage_rate
from clinfact.core.safety import SafetyGate, build_safety_report, hallucinated_claim_count
from clinfact.core.schemas import Document, Prediction
from clinfact.core.scoring import select_best_candidate
from clinfact.core.verification import ClaimVerifier
from clinfact.models.hf_generator import HFChatGenerator


class ClinFactSafeSum:
    """End to end implementation of the proposed ClinFact SafeSum method."""

    method_name = "ClinFact SafeSum"

    def __init__(self, model_config: ModelConfig, pipeline_config: PipelineConfig):
        self.model_config = model_config
        self.pipeline_config = pipeline_config
        self.generator = HFChatGenerator(model_config.phi_model_id, model_config)
        self.fact_extractor = FactExtractor(self.generator, pipeline_config.max_source_chars)
        self.candidate_generator = CandidateGenerator(self.generator, pipeline_config.max_source_chars)
        self.decomposer = ClaimDecomposer(self.generator)
        self.verifier = ClaimVerifier(self.generator, pipeline_config.top_k_evidence)
        self.omission_recoverer = OmissionRecoverer(self.generator)
        self.corrector = Corrector(self.generator)
        self.safety_gate = SafetyGate(self.generator, pipeline_config)

    def run_one(self, doc: Document) -> Dict[str, Any]:
        source = doc.source[: self.pipeline_config.max_source_chars]

        facts = self.fact_extractor.extract(source)
        req_facts = required_facts(facts)

        candidates = self.candidate_generator.generate_candidates(
            source=source,
            required_facts=req_facts,
            n=self.pipeline_config.n_candidates,
        )
        selected = select_best_candidate(
            candidates=candidates,
            source=source,
            required_facts=req_facts,
            decomposer=self.decomposer,
            verifier=self.verifier,
            alpha=self.pipeline_config.alpha,
            beta=self.pipeline_config.beta,
        )
        current_summary = selected
        decision = "pending"
        final_claims = []
        final_verifications = []
        final_audit_errors = []
        final_missing = []
        final_rfcr = 0.0

        for r in range(self.pipeline_config.r_max + 1):
            final_claims = self.decomposer.decompose(current_summary)
            final_verifications = self.verifier.verify_all(final_claims, source)
            bad_claims = [asdict(v) for v in final_verifications if v.label in {"unsupported", "contradicted", "unclear"}]

            final_missing = candidate_omissions(req_facts, final_claims)
            recovered_candidates = self.omission_recoverer.recover(final_missing)
            verified_omissions = []
            for item in recovered_candidates:
                if self.verifier.verify_fact_supported(item["text"], source):
                    verified_omissions.append(item)

            final_audit_errors = deterministic_audit(current_summary, source)
            final_rfcr = required_fact_coverage_rate(req_facts, final_claims)

            if self.safety_gate.pass_condition(final_verifications, final_rfcr, final_audit_errors):
                decision = "pass"
                break

            if r == self.pipeline_config.r_max:
                break

            current_summary = self.corrector.correct(
                summary=current_summary,
                bad_claims=bad_claims,
                verified_omissions=verified_omissions,
                audit_errors=[asdict(e) for e in final_audit_errors],
            )

        if decision != "pass":
            decision = self.safety_gate.final_decision(
                summary=current_summary,
                verifications=final_verifications,
                rfcr=final_rfcr,
                audit_errors=final_audit_errors,
                r=self.pipeline_config.r_max,
            )

        report = build_safety_report(
            doc_id=doc.doc_id,
            decision=decision,
            verifications=final_verifications,
            required_facts=req_facts,
            missing_required_facts=final_missing,
            rfcr=final_rfcr,
            audit_errors=final_audit_errors,
        )

        delivered = current_summary if decision == "pass" else f"WITHHELD SUMMARY. Safety decision: {decision}."
        prediction = Prediction(
            doc_id=doc.doc_id,
            method=self.method_name,
            summary=current_summary,
            delivered_output=delivered,
            decision=decision,
            safety_report=report,
        )

        return {
            "doc_id": doc.doc_id,
            "method": self.method_name,
            "source": doc.source,
            "reference": doc.reference,
            "candidates": candidates,
            "selected_initial_summary": selected,
            "summary": current_summary,
            "delivered_output": delivered,
            "decision": decision,
            "facts": [asdict(f) for f in facts],
            "required_facts": [asdict(f) for f in req_facts],
            "claims": [asdict(c) for c in final_claims],
            "claim_verifications": [asdict(v) for v in final_verifications],
            "missing_required_facts": [asdict(f) for f in final_missing],
            "safety_report": asdict(report),
            "hallucinated_claim_count": hallucinated_claim_count(final_verifications),
            "required_fact_coverage_rate": final_rfcr,
        }

    def run(self, docs: List[Document]) -> List[Dict[str, Any]]:
        return [self.run_one(doc) for doc in docs]
