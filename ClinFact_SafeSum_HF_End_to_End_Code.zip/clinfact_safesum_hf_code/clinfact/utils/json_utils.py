import json
import re
from typing import Any, Dict, List, Optional


def extract_json(text: str) -> Any:
    """Extract and parse the first JSON object or array from a model response."""
    text = text.strip()
    if not text:
        raise ValueError("Empty model response")

    # Remove common markdown fences.
    text = re.sub(r"^```(?:json)?", "", text.strip(), flags=re.IGNORECASE).strip()
    text = re.sub(r"```$", "", text.strip()).strip()

    # Direct parse first.
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # Try array first.
    arr_match = re.search(r"\[[\s\S]*\]", text)
    if arr_match:
        try:
            return json.loads(arr_match.group(0))
        except json.JSONDecodeError:
            pass

    obj_match = re.search(r"\{[\s\S]*\}", text)
    if obj_match:
        try:
            return json.loads(obj_match.group(0))
        except json.JSONDecodeError:
            pass

    raise ValueError(f"Could not parse JSON from response: {text[:300]}")


def safe_json_list(text: str, fallback: Optional[List[Dict[str, Any]]] = None) -> List[Dict[str, Any]]:
    try:
        parsed = extract_json(text)
        if isinstance(parsed, dict):
            for key in ("facts", "claims", "items", "results"):
                if key in parsed and isinstance(parsed[key], list):
                    return parsed[key]
            return [parsed]
        if isinstance(parsed, list):
            return parsed
    except Exception:
        pass
    return fallback or []


def safe_json_dict(text: str, fallback: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    try:
        parsed = extract_json(text)
        if isinstance(parsed, dict):
            return parsed
        if isinstance(parsed, list) and parsed:
            return parsed[0] if isinstance(parsed[0], dict) else {}
    except Exception:
        pass
    return fallback or {}
