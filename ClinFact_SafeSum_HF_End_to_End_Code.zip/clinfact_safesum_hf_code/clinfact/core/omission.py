import json
from typing import Dict, List, Tuple
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from clinfact.core.prompts import OMISSION_RECOVERY_PROMPT, SYSTEM_CLINICAL_SAFETY
from clinfact.core.schemas import AtomicFact, Claim
from clinfact.models.hf_generator import HFChatGenerator
from clinfact.utils.json_utils import safe_json_list


def fact_coverage_label(fact: AtomicFact, claims: List[Claim], covered_threshold: float = 0.55, partial_threshold: float = 0.30) -> str:
    if not claims:
        return "missing"
    texts = [c.text for c in claims] + [fact.text]
    vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
    try:
        mat = vectorizer.fit_transform(texts)
        score = float(cosine_similarity(mat[-1], mat[:-1]).max())
    except ValueError:
        score = 0.0
    if score >= covered_threshold:
        return "covered"
    if score >= partial_threshold:
        return "partial"
    return "missing"


def required_fact_coverage_rate(required_facts: List[AtomicFact], claims: List[Claim]) -> float:
    if not required_facts:
        return 1.0
    covered = sum(1 for f in required_facts if fact_coverage_label(f, claims) == "covered")
    return covered / len(required_facts)


def candidate_omissions(required_facts: List[AtomicFact], claims: List[Claim]) -> List[AtomicFact]:
    return [f for f in required_facts if fact_coverage_label(f, claims) in {"missing", "partial"}]


class OmissionRecoverer:
    def __init__(self, generator: HFChatGenerator):
        self.generator = generator

    def recover(self, omitted_facts: List[AtomicFact]) -> List[Dict[str, str]]:
        if not omitted_facts:
            return []
        prompt = OMISSION_RECOVERY_PROMPT.format(
            omitted_facts=json.dumps([f.__dict__ for f in omitted_facts], ensure_ascii=False, indent=2)
        )
        raw = self.generator.generate(prompt, system=SYSTEM_CLINICAL_SAFETY)
        rows = safe_json_list(raw)
        recovered: List[Dict[str, str]] = []
        for idx, row in enumerate(rows):
            text = str(row.get("text", "")).strip()
            if text:
                recovered.append({"fact_id": str(row.get("fact_id") or f"R{idx+1}"), "text": text})
        return recovered
