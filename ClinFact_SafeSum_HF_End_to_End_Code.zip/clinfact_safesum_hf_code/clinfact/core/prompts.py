SYSTEM_CLINICAL_SAFETY = """You are a careful clinical NLP assistant. Use only the provided source text. Do not invent diagnoses, medications, doses, dates, results, or follow up plans. When information is absent, say it is absent instead of guessing."""

FACT_EXTRACTION_PROMPT = """Extract atomic clinical source facts from the source document.

Rules:
1. Each fact must be independently verifiable.
2. Split complex statements into separate facts.
3. Mark required_level as one of: must, should, optional.
4. Use must for allergies, active serious diagnoses, critical abnormal results, medications, procedures, discharge or follow up instructions, safety risks, and clear negations that affect care.
5. Use should for important history, symptoms, exam findings, normal results that contextualize the case, and care plan details.
6. Use optional for background or low risk context.
7. Copy a short evidence_quote from the source text.
8. Return valid JSON only.

Return this JSON schema:
[
  {{
    "fact_id": "F1",
    "text": "atomic fact",
    "required_level": "must|should|optional",
    "category": "diagnosis|medication|allergy|symptom|lab|imaging|procedure|plan|negation|history|other",
    "evidence_quote": "short source quote"
  }}
]

SOURCE DOCUMENT:
{source}
"""

PROPOSED_CANDIDATE_SUMMARY_PROMPT = """Generate a concise clinical summary using only the provided source document and required facts.

Safety rules:
1. Do not add any information that is not directly supported by the source.
2. Preserve medication name, dose, route, frequency, timing, and negation exactly when stated.
3. Preserve laterality, temporality, diagnosis status, abnormal results, procedures, allergies, and follow up requirements.
4. Include clinically required facts when relevant.
5. If a required fact cannot be safely integrated, do not invent it.
6. Use clear clinical prose.

SOURCE DOCUMENT:
{source}

REQUIRED FACTS:
{required_facts}

Write only the summary.
"""

RAW_SUMMARY_PROMPT = """Summarize the following clinical note concisely.

CLINICAL NOTE:
{source}
"""

PROMPT_LLAMA_SUMMARY_PROMPT = """You are writing a clinical summary.

Follow these instructions:
1. Use only the clinical note.
2. Include diagnoses, symptoms, important results, medications, allergies, procedures, and follow up plans.
3. Avoid unsupported additions.
4. Keep the summary concise and clinically useful.

CLINICAL NOTE:
{source}

SUMMARY:
"""

RAG_LLAMA_SUMMARY_PROMPT = """Write a clinical summary using only the retrieved evidence chunks below.

Rules:
1. Do not use outside knowledge.
2. Do not add facts absent from the evidence chunks.
3. Preserve medication, dosage, route, negation, timing, laterality, and follow up details.

RETRIEVED EVIDENCE:
{evidence}

SUMMARY:
"""

CLAIM_DECOMPOSITION_PROMPT = """Decompose the summary into atomic clinical claims.

Rules:
1. Each claim must contain one factual assertion.
2. Split medication name, dose, route, and frequency if needed.
3. Preserve negation, laterality, and temporality.
4. Return valid JSON only.

Return schema:
[
  {{"claim_id": "C1", "text": "atomic claim"}}
]

SUMMARY:
{summary}
"""

CLAIM_VERIFICATION_PROMPT = """Verify one clinical claim against the retrieved source evidence.

Labels:
- supported: the evidence directly supports the claim.
- contradicted: the evidence directly conflicts with the claim.
- unsupported: the claim is not found in the evidence or source.
- unclear: the evidence is insufficient or ambiguous.

Severity:
- critical: likely to cause serious patient safety risk, such as wrong critical medication, allergy, diagnosis, procedure, critical result, or dangerous negation error.
- major: clinically meaningful error that could mislead care but is not immediately critical.
- minor: low risk factual or wording issue.

Check medication identity, dosage, route, frequency, negation, laterality, temporality, diagnosis status, abnormal results, procedures, and follow up.

Return valid JSON only with this schema:
{{
  "label": "supported|contradicted|unsupported|unclear",
  "severity": "minor|major|critical",
  "evidence_quote": "short evidence quote or empty string",
  "rationale": "brief reason"
}}

CLAIM:
{claim}

RETRIEVED EVIDENCE:
{evidence}
"""

OMISSION_RECOVERY_PROMPT = """Convert the missing or partially covered required source facts into concise summary ready statements.

Rules:
1. Use only the given facts.
2. Do not add new information.
3. Preserve medication, dosage, route, negation, laterality, temporality, and follow up details exactly.
4. Return valid JSON only.

Return schema:
[
  {{"fact_id": "F1", "text": "summary ready required fact"}}
]

MISSING OR PARTIAL REQUIRED FACTS:
{omitted_facts}
"""

FACT_VERIFICATION_PROMPT = """Verify whether the candidate recovered fact is directly supported by the source document.

Return valid JSON only:
{{"label": "sup|not_sup", "evidence_quote": "short quote", "rationale": "brief reason"}}

FACT:
{fact}

SOURCE DOCUMENT:
{source}
"""

CORRECTION_PROMPT = """Revise the current clinical summary using the safety feedback.

Rules:
1. Remove unsupported claims.
2. Correct contradicted claims according to source evidence.
3. Resolve unclear claims only if the provided evidence makes them clear. Otherwise remove or neutralize them.
4. Add only verified omitted facts.
5. Fix deterministic audit errors.
6. Do not add any new unsupported information.
7. Keep the summary concise and clinically readable.

CURRENT SUMMARY:
{summary}

FLAGGED CLAIMS:
{bad_claims}

VERIFIED OMITTED FACTS TO ADD:
{verified_omissions}

DETERMINISTIC AUDIT ERRORS:
{audit_errors}

Return only the corrected summary.
"""

SAFETY_DECISION_PROMPT = """Assign a final safety decision for the audited clinical summary.

Decision rules:
- pass: no more than the allowed hallucinated claim count, required fact coverage is at or above threshold, and no major or critical error remains.
- fail: unresolved critical error remains after correction.
- abstain: residual uncertainty remains, major error remains, or required fact coverage is below threshold.

Return valid JSON only:
{{"decision": "abstain|fail", "reason": "brief reason"}}

SUMMARY:
{summary}

AUDIT STATE:
{audit_state}
"""
