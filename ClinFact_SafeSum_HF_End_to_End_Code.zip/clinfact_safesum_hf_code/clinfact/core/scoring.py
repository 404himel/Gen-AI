from typing import List
from clinfact.core.claim_processing import ClaimDecomposer
from clinfact.core.omission import required_fact_coverage_rate
from clinfact.core.schemas import AtomicFact
from clinfact.core.verification import ClaimVerifier


def hallucination_rate_for_summary(summary: str, source: str, decomposer: ClaimDecomposer, verifier: ClaimVerifier) -> float:
    claims = decomposer.decompose(summary)
    if not claims:
        return 1.0
    verifications = verifier.verify_all(claims, source)
    bad = sum(1 for v in verifications if v.label in {"unsupported", "contradicted"})
    return bad / len(claims)


def coverage_for_summary(summary: str, required_facts: List[AtomicFact], decomposer: ClaimDecomposer) -> float:
    claims = decomposer.decompose(summary)
    return required_fact_coverage_rate(required_facts, claims)


def select_best_candidate(candidates: List[str], source: str, required_facts: List[AtomicFact], decomposer: ClaimDecomposer, verifier: ClaimVerifier, alpha: float, beta: float) -> str:
    if not candidates:
        return ""
    best_score = None
    best_summary = candidates[0]
    for summary in candidates:
        coverage = coverage_for_summary(summary, required_facts, decomposer)
        hallucination = hallucination_rate_for_summary(summary, source, decomposer, verifier)
        score = alpha * coverage - beta * hallucination
        if best_score is None or score > best_score:
            best_score = score
            best_summary = summary
    return best_summary
