from typing import List
from clinfact.core.prompts import PROPOSED_CANDIDATE_SUMMARY_PROMPT, SYSTEM_CLINICAL_SAFETY
from clinfact.core.schemas import AtomicFact
from clinfact.core.fact_extraction import facts_to_json
from clinfact.models.hf_generator import HFChatGenerator


class CandidateGenerator:
    def __init__(self, generator: HFChatGenerator, max_source_chars: int = 24000):
        self.generator = generator
        self.max_source_chars = max_source_chars

    def generate_candidates(self, source: str, required_facts: List[AtomicFact], n: int = 5) -> List[str]:
        candidates: List[str] = []
        required_json = facts_to_json(required_facts)
        for _ in range(n):
            prompt = PROPOSED_CANDIDATE_SUMMARY_PROMPT.format(
                source=source[: self.max_source_chars],
                required_facts=required_json,
            )
            summary = self.generator.generate(prompt, system=SYSTEM_CLINICAL_SAFETY).strip()
            if summary:
                candidates.append(summary)
        return candidates
