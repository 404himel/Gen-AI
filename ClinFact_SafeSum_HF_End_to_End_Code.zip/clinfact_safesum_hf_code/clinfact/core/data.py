from typing import List
from clinfact.core.schemas import Document
from clinfact.utils.io import read_table


def load_documents(path: str) -> List[Document]:
    rows = read_table(path)
    docs: List[Document] = []
    for idx, row in enumerate(rows):
        doc_id = str(row.get("id") or row.get("doc_id") or row.get("note_id") or f"doc_{idx:04d}")
        source = row.get("source") or row.get("note") or row.get("clinical_note") or row.get("dialogue")
        if not source:
            raise ValueError("Each row must include a source, note, clinical_note, or dialogue field.")
        reference = row.get("reference") or row.get("target") or row.get("summary") or row.get("gold_summary")
        metadata = {k: v for k, v in row.items() if k not in {"id", "doc_id", "note_id", "source", "note", "clinical_note", "dialogue", "reference", "target", "summary", "gold_summary"}}
        docs.append(Document(doc_id=doc_id, source=str(source), reference=str(reference) if reference else None, metadata=metadata))
    return docs
