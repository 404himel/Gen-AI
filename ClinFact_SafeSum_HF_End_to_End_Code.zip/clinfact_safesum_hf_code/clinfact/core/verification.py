from typing import List
from clinfact.core.prompts import CLAIM_VERIFICATION_PROMPT, FACT_VERIFICATION_PROMPT, SYSTEM_CLINICAL_SAFETY
from clinfact.core.retrieval import retrieve_evidence, evidence_to_text
from clinfact.core.schemas import Claim, ClaimVerification
from clinfact.models.hf_generator import HFChatGenerator
from clinfact.utils.json_utils import safe_json_dict


class ClaimVerifier:
    def __init__(self, generator: HFChatGenerator, k: int = 5):
        self.generator = generator
        self.k = k

    def verify_claim(self, claim: Claim, source: str) -> ClaimVerification:
        chunks = retrieve_evidence(claim.text, source, self.k)
        prompt = CLAIM_VERIFICATION_PROMPT.format(claim=claim.text, evidence=evidence_to_text(chunks))
        raw = self.generator.generate(prompt, system=SYSTEM_CLINICAL_SAFETY)
        row = safe_json_dict(raw)
        label = str(row.get("label", "unclear")).lower().strip()
        if label not in {"supported", "contradicted", "unsupported", "unclear"}:
            label = "unclear"
        severity = str(row.get("severity", "minor")).lower().strip()
        if severity not in {"minor", "major", "critical"}:
            severity = "minor"
        return ClaimVerification(
            claim_id=claim.claim_id,
            claim_text=claim.text,
            label=label,
            severity=severity,
            evidence_quote=str(row.get("evidence_quote", "")),
            rationale=str(row.get("rationale", "")),
        )

    def verify_all(self, claims: List[Claim], source: str) -> List[ClaimVerification]:
        return [self.verify_claim(c, source) for c in claims]

    def verify_fact_supported(self, fact_text: str, source: str) -> bool:
        prompt = FACT_VERIFICATION_PROMPT.format(fact=fact_text, source=source)
        raw = self.generator.generate(prompt, system=SYSTEM_CLINICAL_SAFETY)
        row = safe_json_dict(raw)
        return str(row.get("label", "not_sup")).lower().strip() == "sup"
