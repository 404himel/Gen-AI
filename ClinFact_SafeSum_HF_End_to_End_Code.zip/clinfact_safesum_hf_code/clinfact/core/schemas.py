from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional


@dataclass
class Document:
    doc_id: str
    source: str
    reference: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class AtomicFact:
    fact_id: str
    text: str
    required_level: str = "optional"
    category: str = "other"
    evidence_quote: str = ""


@dataclass
class Claim:
    claim_id: str
    text: str


@dataclass
class ClaimVerification:
    claim_id: str
    claim_text: str
    label: str
    severity: str = "minor"
    evidence_quote: str = ""
    rationale: str = ""


@dataclass
class AuditError:
    error_type: str
    severity: str
    text: str
    rationale: str = ""


@dataclass
class SafetyReport:
    doc_id: str
    decision: str
    hallucinated_claim_count: int
    required_fact_coverage_rate: float
    unsupported_count: int
    contradicted_count: int
    unclear_count: int
    audit_errors: List[Dict[str, Any]]
    claim_verifications: List[Dict[str, Any]]
    missing_required_facts: List[Dict[str, Any]]
    delivered: bool


@dataclass
class Prediction:
    doc_id: str
    method: str
    summary: str
    delivered_output: str
    decision: str = "pass"
    safety_report: Optional[SafetyReport] = None


def to_dict(obj: Any) -> Dict[str, Any]:
    return asdict(obj)
