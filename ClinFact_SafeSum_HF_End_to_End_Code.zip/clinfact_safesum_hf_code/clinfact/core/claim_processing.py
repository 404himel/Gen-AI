from typing import List
from clinfact.core.prompts import CLAIM_DECOMPOSITION_PROMPT, SYSTEM_CLINICAL_SAFETY
from clinfact.core.schemas import Claim
from clinfact.models.hf_generator import HFChatGenerator
from clinfact.utils.json_utils import safe_json_list


class ClaimDecomposer:
    def __init__(self, generator: HFChatGenerator):
        self.generator = generator

    def decompose(self, summary: str) -> List[Claim]:
        prompt = CLAIM_DECOMPOSITION_PROMPT.format(summary=summary)
        raw = self.generator.generate(prompt, system=SYSTEM_CLINICAL_SAFETY)
        rows = safe_json_list(raw)
        claims: List[Claim] = []
        for idx, row in enumerate(rows):
            text = str(row.get("text", "")).strip()
            if text:
                claims.append(Claim(claim_id=str(row.get("claim_id") or f"C{idx+1}"), text=text))
        return claims
