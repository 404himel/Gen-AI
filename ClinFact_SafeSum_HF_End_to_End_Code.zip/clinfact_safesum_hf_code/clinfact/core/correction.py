import json
from typing import Any, Dict, List
from clinfact.core.prompts import CORRECTION_PROMPT, SYSTEM_CLINICAL_SAFETY
from clinfact.models.hf_generator import HFChatGenerator


class Corrector:
    def __init__(self, generator: HFChatGenerator):
        self.generator = generator

    def correct(self, summary: str, bad_claims: List[Dict[str, Any]], verified_omissions: List[Dict[str, Any]], audit_errors: List[Dict[str, Any]]) -> str:
        prompt = CORRECTION_PROMPT.format(
            summary=summary,
            bad_claims=json.dumps(bad_claims, ensure_ascii=False, indent=2),
            verified_omissions=json.dumps(verified_omissions, ensure_ascii=False, indent=2),
            audit_errors=json.dumps(audit_errors, ensure_ascii=False, indent=2),
        )
        return self.generator.generate(prompt, system=SYSTEM_CLINICAL_SAFETY).strip()
