import re
from typing import List
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


def split_sentences(text: str) -> List[str]:
    text = re.sub(r"\s+", " ", text.strip())
    if not text:
        return []
    parts = re.split(r"(?<=[.!?])\s+|\n+", text)
    return [p.strip() for p in parts if len(p.strip()) > 1]


def chunk_text(text: str, max_chars: int = 900) -> List[str]:
    sentences = split_sentences(text)
    chunks: List[str] = []
    current = ""
    for sent in sentences:
        if len(current) + len(sent) + 1 <= max_chars:
            current = f"{current} {sent}".strip()
        else:
            if current:
                chunks.append(current)
            current = sent
    if current:
        chunks.append(current)
    return chunks or [text[:max_chars]]


def retrieve_evidence(query: str, source: str, k: int = 5) -> List[str]:
    chunks = chunk_text(source)
    if len(chunks) <= k:
        return chunks
    vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
    matrix = vectorizer.fit_transform(chunks + [query])
    scores = cosine_similarity(matrix[-1], matrix[:-1]).flatten()
    top_idx = scores.argsort()[::-1][:k]
    return [chunks[i] for i in top_idx]


def evidence_to_text(chunks: List[str]) -> str:
    return "\n".join([f"[{i+1}] {chunk}" for i, chunk in enumerate(chunks)])
