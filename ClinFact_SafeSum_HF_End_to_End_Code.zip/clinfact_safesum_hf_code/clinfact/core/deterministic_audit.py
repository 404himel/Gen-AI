import re
from typing import List
from clinfact.core.schemas import AuditError


def _numbers(text: str) -> set[str]:
    return set(re.findall(r"\b\d+(?:\.\d+)?\b", text))


def _medication_patterns(text: str) -> List[str]:
    pattern = re.compile(r"\b([A-Za-z][A-Za-z-]+)\s+(\d+(?:\.\d+)?)\s*(mg|mcg|g|units?|iu|ml)\b", re.IGNORECASE)
    return [" ".join(m).lower() for m in pattern.findall(text)]


def _negation_terms(text: str) -> set[str]:
    terms = set()
    for phrase in ["no", "denies", "without", "negative for", "not", "absence of"]:
        if phrase in text.lower():
            terms.add(phrase)
    return terms


def deterministic_audit(summary: str, source: str) -> List[AuditError]:
    """Lightweight deterministic checks for numeric, medication, and negation risks.

    These checks are conservative flags. Final decisions should still use source grounded verification.
    """
    errors: List[AuditError] = []

    source_nums = _numbers(source)
    summary_nums = _numbers(summary)
    extra_nums = summary_nums - source_nums
    for n in sorted(extra_nums):
        errors.append(AuditError(
            error_type="numeric_mismatch",
            severity="major",
            text=f"Number {n} appears in summary but not in source.",
            rationale="Potential unsupported numeric value.",
        ))

    source_meds = set(_medication_patterns(source))
    summary_meds = set(_medication_patterns(summary))
    for med in sorted(summary_meds - source_meds):
        errors.append(AuditError(
            error_type="medication_mismatch",
            severity="critical",
            text=f"Medication or dose pattern '{med}' appears in summary but not in source.",
            rationale="Medication identity or dose mismatch can be high risk.",
        ))

    # Flag if summary introduces explicit negation words absent from source.
    if _negation_terms(summary) and not _negation_terms(source):
        errors.append(AuditError(
            error_type="negation_shift",
            severity="major",
            text="Summary contains negation terms not present in source.",
            rationale="Potential negation error.",
        ))

    return errors


def no_major_critical(errors: List[AuditError]) -> bool:
    return all(e.severity not in {"major", "critical"} for e in errors)


def has_critical(errors: List[AuditError]) -> bool:
    return any(e.severity == "critical" for e in errors)
