import json
from typing import List
from clinfact.core.prompts import FACT_EXTRACTION_PROMPT, SYSTEM_CLINICAL_SAFETY
from clinfact.core.schemas import AtomicFact
from clinfact.models.hf_generator import HFChatGenerator
from clinfact.utils.json_utils import safe_json_list


class FactExtractor:
    def __init__(self, generator: HFChatGenerator, max_source_chars: int = 24000):
        self.generator = generator
        self.max_source_chars = max_source_chars

    def extract(self, source: str) -> List[AtomicFact]:
        prompt = FACT_EXTRACTION_PROMPT.format(source=source[: self.max_source_chars])
        raw = self.generator.generate(prompt, system=SYSTEM_CLINICAL_SAFETY)
        rows = safe_json_list(raw)
        facts: List[AtomicFact] = []
        for idx, row in enumerate(rows):
            text = str(row.get("text", "")).strip()
            if not text:
                continue
            level = str(row.get("required_level", "optional")).lower().strip()
            if level not in {"must", "should", "optional"}:
                level = "optional"
            facts.append(AtomicFact(
                fact_id=str(row.get("fact_id") or f"F{idx+1}"),
                text=text,
                required_level=level,
                category=str(row.get("category", "other")),
                evidence_quote=str(row.get("evidence_quote", "")),
            ))
        return facts


def required_facts(facts: List[AtomicFact]) -> List[AtomicFact]:
    return [f for f in facts if f.required_level in {"must", "should"}]


def facts_to_json(facts: List[AtomicFact]) -> str:
    return json.dumps([f.__dict__ for f in facts], ensure_ascii=False, indent=2)
