import json
from dataclasses import asdict
from typing import Any, Dict, List
from clinfact.config import PipelineConfig
from clinfact.core.deterministic_audit import has_critical, no_major_critical
from clinfact.core.prompts import SAFETY_DECISION_PROMPT, SYSTEM_CLINICAL_SAFETY
from clinfact.core.schemas import AuditError, AtomicFact, Claim, ClaimVerification, SafetyReport
from clinfact.models.hf_generator import HFChatGenerator
from clinfact.utils.json_utils import safe_json_dict


def hallucinated_claim_count(verifications: List[ClaimVerification]) -> int:
    return sum(1 for v in verifications if v.label in {"unsupported", "contradicted"})


def label_counts(verifications: List[ClaimVerification]) -> Dict[str, int]:
    return {
        "supported": sum(1 for v in verifications if v.label == "supported"),
        "unsupported": sum(1 for v in verifications if v.label == "unsupported"),
        "contradicted": sum(1 for v in verifications if v.label == "contradicted"),
        "unclear": sum(1 for v in verifications if v.label == "unclear"),
    }


def has_major_or_critical_claim_error(verifications: List[ClaimVerification]) -> bool:
    return any(v.label in {"unsupported", "contradicted", "unclear"} and v.severity in {"major", "critical"} for v in verifications)


class SafetyGate:
    def __init__(self, generator: HFChatGenerator, config: PipelineConfig):
        self.generator = generator
        self.config = config

    def pass_condition(self, verifications: List[ClaimVerification], rfcr: float, audit_errors: List[AuditError]) -> bool:
        h = hallucinated_claim_count(verifications)
        return h <= self.config.h_max and rfcr >= self.config.tau and no_major_critical(audit_errors) and not has_major_or_critical_claim_error(verifications)

    def final_decision(self, summary: str, verifications: List[ClaimVerification], rfcr: float, audit_errors: List[AuditError], r: int) -> str:
        if self.pass_condition(verifications, rfcr, audit_errors):
            return "pass"
        if has_critical(audit_errors) or any(v.severity == "critical" and v.label != "supported" for v in verifications):
            return "fail"

        audit_state = {
            "hallucinated_claim_count": hallucinated_claim_count(verifications),
            "required_fact_coverage_rate": rfcr,
            "audit_errors": [asdict(e) for e in audit_errors],
            "claim_verifications": [asdict(v) for v in verifications],
            "round": r,
            "h_max": self.config.h_max,
            "tau": self.config.tau,
        }
        prompt = SAFETY_DECISION_PROMPT.format(summary=summary, audit_state=json.dumps(audit_state, ensure_ascii=False, indent=2))
        raw = self.generator.generate(prompt, system=SYSTEM_CLINICAL_SAFETY)
        decision = str(safe_json_dict(raw).get("decision", "abstain")).lower().strip()
        if decision not in {"abstain", "fail"}:
            decision = "abstain"
        return decision


def build_safety_report(doc_id: str, decision: str, verifications: List[ClaimVerification], required_facts: List[AtomicFact], missing_required_facts: List[AtomicFact], rfcr: float, audit_errors: List[AuditError]) -> SafetyReport:
    counts = label_counts(verifications)
    return SafetyReport(
        doc_id=doc_id,
        decision=decision,
        hallucinated_claim_count=hallucinated_claim_count(verifications),
        required_fact_coverage_rate=rfcr,
        unsupported_count=counts["unsupported"],
        contradicted_count=counts["contradicted"],
        unclear_count=counts["unclear"],
        audit_errors=[asdict(e) for e in audit_errors],
        claim_verifications=[asdict(v) for v in verifications],
        missing_required_facts=[asdict(f) for f in missing_required_facts],
        delivered=(decision == "pass"),
    )
