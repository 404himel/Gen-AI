from collections import defaultdict
from typing import Any, Dict, List


def compute_rouge(predictions: List[Dict[str, Any]]) -> Dict[str, float]:
    pairs = [(p.get("summary", ""), p.get("reference")) for p in predictions if p.get("reference")]
    if not pairs:
        return {}
    try:
        from rouge_score import rouge_scorer
    except ImportError:
        return {}
    scorer = rouge_scorer.RougeScorer(["rouge1", "rouge2", "rougeL"], use_stemmer=True)
    vals = defaultdict(list)
    for pred, ref in pairs:
        scores = scorer.score(str(ref), str(pred))
        vals["rouge1"].append(scores["rouge1"].fmeasure)
        vals["rouge2"].append(scores["rouge2"].fmeasure)
        vals["rougeL"].append(scores["rougeL"].fmeasure)
    return {k: float(sum(v) / len(v)) for k, v in vals.items()}


def compute_bertscore(predictions: List[Dict[str, Any]]) -> Dict[str, float]:
    pairs = [(p.get("summary", ""), p.get("reference")) for p in predictions if p.get("reference")]
    if not pairs:
        return {}
    try:
        from bert_score import score
    except ImportError:
        return {}
    preds = [str(p) for p, _ in pairs]
    refs = [str(r) for _, r in pairs]
    _, _, f1 = score(preds, refs, lang="en", verbose=False)
    return {"bertscore_f1": float(f1.mean().item())}


def compute_safety_summary(predictions: List[Dict[str, Any]]) -> Dict[str, Any]:
    reports = [p.get("safety_report") for p in predictions if p.get("safety_report")]
    if not reports:
        return {}
    n = len(reports)
    decisions = defaultdict(int)
    unsupported = contradicted = unclear = h_count = 0
    rfcr_total = 0.0
    for r in reports:
        decisions[r.get("decision", "unknown")] += 1
        unsupported += int(r.get("unsupported_count", 0))
        contradicted += int(r.get("contradicted_count", 0))
        unclear += int(r.get("unclear_count", 0))
        h_count += int(r.get("hallucinated_claim_count", 0))
        rfcr_total += float(r.get("required_fact_coverage_rate", 0.0))
    return {
        "n_reports": n,
        "decision_counts": dict(decisions),
        "mean_required_fact_coverage_rate": rfcr_total / n if n else 0.0,
        "total_hallucinated_claims": h_count,
        "total_unsupported_claims": unsupported,
        "total_contradicted_claims": contradicted,
        "total_unclear_claims": unclear,
    }


def evaluate_predictions(predictions: List[Dict[str, Any]], compute_bert: bool = False) -> Dict[str, Any]:
    result: Dict[str, Any] = {}
    result.update(compute_rouge(predictions))
    if compute_bert:
        result.update(compute_bertscore(predictions))
    safety = compute_safety_summary(predictions)
    if safety:
        result["safety"] = safety
    return result


def aggregate_by_method(all_predictions: List[Dict[str, Any]], compute_bert: bool = False) -> Dict[str, Any]:
    groups = defaultdict(list)
    for p in all_predictions:
        groups[p.get("method", "unknown")].append(p)
    return {method: evaluate_predictions(rows, compute_bert=compute_bert) for method, rows in groups.items()}
