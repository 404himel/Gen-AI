from dataclasses import asdict
from typing import Any, Dict, List
from clinfact.config import ModelConfig, PipelineConfig
from clinfact.core.claim_processing import ClaimDecomposer
from clinfact.core.fact_extraction import FactExtractor, required_facts
from clinfact.core.omission import candidate_omissions, required_fact_coverage_rate
from clinfact.core.schemas import Document
from clinfact.core.verification import ClaimVerifier
from clinfact.models.hf_generator import HFChatGenerator


class OfflineSafetyEvaluator:
    """Use the same source grounded verifier to audit baseline summaries."""

    def __init__(self, model_config: ModelConfig, pipeline_config: PipelineConfig):
        self.generator = HFChatGenerator(model_config.phi_model_id, model_config)
        self.fact_extractor = FactExtractor(self.generator, pipeline_config.max_source_chars)
        self.decomposer = ClaimDecomposer(self.generator)
        self.verifier = ClaimVerifier(self.generator, pipeline_config.top_k_evidence)

    def audit(self, doc: Document, summary: str) -> Dict[str, Any]:
        facts = self.fact_extractor.extract(doc.source)
        req = required_facts(facts)
        claims = self.decomposer.decompose(summary)
        verifications = self.verifier.verify_all(claims, doc.source)
        missing = candidate_omissions(req, claims)
        rfcr = required_fact_coverage_rate(req, claims)
        h = sum(1 for v in verifications if v.label in {"unsupported", "contradicted"})
        return {
            "claims": [asdict(c) for c in claims],
            "claim_verifications": [asdict(v) for v in verifications],
            "required_fact_count": len(req),
            "missing_required_fact_count": len(missing),
            "required_fact_coverage_rate": rfcr,
            "hallucinated_claim_count": h,
            "hallucination_rate": h / len(claims) if claims else 0.0,
        }
