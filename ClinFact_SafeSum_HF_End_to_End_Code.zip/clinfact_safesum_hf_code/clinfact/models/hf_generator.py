import os
from typing import Dict, List, Optional

from clinfact.config import ModelConfig


class HFChatGenerator:
    """Small wrapper around Hugging Face causal LM chat models."""

    def __init__(self, model_id: str, config: ModelConfig):
        self.model_id = model_id
        self.config = config
        self.mock = config.mock
        self.tokenizer = None
        self.model = None
        if not self.mock:
            self._load()

    def _load(self) -> None:
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer

        token = self.config.hf_token or os.getenv("HF_TOKEN")
        dtype = self.config.torch_dtype
        if dtype == "auto":
            torch_dtype = "auto"
        elif dtype == "float16":
            torch_dtype = torch.float16
        elif dtype == "bfloat16":
            torch_dtype = torch.bfloat16
        else:
            torch_dtype = "auto"

        self.tokenizer = AutoTokenizer.from_pretrained(
            self.model_id,
            token=token,
            trust_remote_code=self.config.trust_remote_code,
        )
        if self.tokenizer.pad_token_id is None and self.tokenizer.eos_token_id is not None:
            self.tokenizer.pad_token_id = self.tokenizer.eos_token_id

        load_kwargs = dict(
            token=token,
            device_map=self.config.device_map,
            torch_dtype=torch_dtype,
            trust_remote_code=self.config.trust_remote_code,
        )
        if self.config.load_in_4bit:
            load_kwargs["load_in_4bit"] = True

        self.model = AutoModelForCausalLM.from_pretrained(self.model_id, **load_kwargs)
        self.model.eval()

    def generate(self, prompt: str, system: Optional[str] = None, max_new_tokens: Optional[int] = None) -> str:
        if self.mock:
            return self._mock_response(prompt)

        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})
        return self.generate_messages(messages, max_new_tokens=max_new_tokens)

    def generate_messages(self, messages: List[Dict[str, str]], max_new_tokens: Optional[int] = None) -> str:
        if self.mock:
            combined = "\n".join(m.get("content", "") for m in messages)
            return self._mock_response(combined)

        import torch

        max_new_tokens = max_new_tokens or self.config.max_new_tokens
        if hasattr(self.tokenizer, "apply_chat_template") and self.tokenizer.chat_template:
            input_ids = self.tokenizer.apply_chat_template(
                messages,
                add_generation_prompt=True,
                return_tensors="pt",
            )
        else:
            prompt = "\n".join([f"{m['role'].upper()}: {m['content']}" for m in messages]) + "\nASSISTANT:"
            input_ids = self.tokenizer(prompt, return_tensors="pt").input_ids

        input_ids = input_ids.to(self.model.device)
        with torch.no_grad():
            output_ids = self.model.generate(
                input_ids=input_ids,
                max_new_tokens=max_new_tokens,
                do_sample=self.config.do_sample,
                temperature=self.config.temperature if self.config.do_sample else None,
                top_p=self.config.top_p if self.config.do_sample else None,
                pad_token_id=self.tokenizer.pad_token_id,
                eos_token_id=self.tokenizer.eos_token_id,
            )
        new_tokens = output_ids[0][input_ids.shape[-1]:]
        return self.tokenizer.decode(new_tokens, skip_special_tokens=True).strip()

    def _mock_response(self, prompt: str) -> str:
        p = prompt.lower()
        if "extract atomic clinical source facts" in p:
            return """[
  {"fact_id":"F1","text":"The patient has type 2 diabetes mellitus.","required_level":"must","category":"diagnosis","evidence_quote":"type 2 diabetes mellitus"},
  {"fact_id":"F2","text":"The patient is taking metformin 500 mg twice daily.","required_level":"must","category":"medication","evidence_quote":"metformin 500 mg twice daily"},
  {"fact_id":"F3","text":"No known drug allergies were documented.","required_level":"must","category":"allergy","evidence_quote":"No known drug allergies"}
]"""
        if "decompose the summary into atomic clinical claims" in p:
            return """[
  {"claim_id":"C1","text":"The patient has type 2 diabetes mellitus."},
  {"claim_id":"C2","text":"The patient is taking metformin 500 mg twice daily."},
  {"claim_id":"C3","text":"No known drug allergies were documented."}
]"""
        if "verify one clinical claim" in p:
            return """{"label":"supported","severity":"minor","evidence_quote":"mock evidence","rationale":"The claim is supported by the source text."}"""
        if "convert the missing or partially covered" in p:
            return "[]"
        if "verify whether the candidate recovered fact" in p:
            return "{" + "\"label\":\"sup\",\"evidence_quote\":\"mock evidence\",\"rationale\":\"Supported.\"}"
        if "assign a final safety decision" in p:
            return "{" + "\"decision\":\"abstain\",\"reason\":\"Residual uncertainty remains.\"}"
        if "revise the current clinical summary" in p:
            return "The patient has type 2 diabetes mellitus and is taking metformin 500 mg twice daily. No known drug allergies were documented."
        return "The patient has type 2 diabetes mellitus and is taking metformin 500 mg twice daily. No known drug allergies were documented."
