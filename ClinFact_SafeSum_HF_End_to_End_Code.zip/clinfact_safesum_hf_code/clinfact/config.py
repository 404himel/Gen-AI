from dataclasses import dataclass
from typing import Optional


@dataclass
class ModelConfig:
    phi_model_id: str = "microsoft/Phi-3-mini-128k-instruct"
    llama_model_id: str = "meta-llama/Meta-Llama-3.1-8B-Instruct"
    device_map: str = "auto"
    torch_dtype: str = "auto"
    max_new_tokens: int = 768
    temperature: float = 0.2
    top_p: float = 0.9
    do_sample: bool = False
    load_in_4bit: bool = False
    trust_remote_code: bool = True
    hf_token: Optional[str] = None
    mock: bool = False


@dataclass
class PipelineConfig:
    n_candidates: int = 5
    alpha: float = 0.60
    beta: float = 0.40
    top_k_evidence: int = 5
    h_max: int = 1
    tau: float = 0.90
    r_max: int = 2
    max_source_chars: int = 24000
    max_summary_chars: int = 4000
    required_levels: tuple = ("must", "should")


@dataclass
class RunConfig:
    data_path: str
    out_dir: str
    model: ModelConfig
    pipeline: PipelineConfig
