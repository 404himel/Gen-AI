from typing import Any, Dict, List
from clinfact.config import ModelConfig, PipelineConfig
from clinfact.core.prompts import RAW_SUMMARY_PROMPT, SYSTEM_CLINICAL_SAFETY
from clinfact.core.schemas import Document
from clinfact.models.hf_generator import HFChatGenerator


class RawPhi3Baseline:
    method_name = "Raw Phi 3 mini 128k instruct"

    def __init__(self, model_config: ModelConfig, pipeline_config: PipelineConfig):
        self.model_config = model_config
        self.pipeline_config = pipeline_config
        self.generator = HFChatGenerator(model_config.phi_model_id, model_config)

    def run_one(self, doc: Document) -> Dict[str, Any]:
        prompt = RAW_SUMMARY_PROMPT.format(source=doc.source[: self.pipeline_config.max_source_chars])
        summary = self.generator.generate(prompt, system=SYSTEM_CLINICAL_SAFETY).strip()
        return {
            "doc_id": doc.doc_id,
            "method": self.method_name,
            "source": doc.source,
            "reference": doc.reference,
            "summary": summary,
            "delivered_output": summary,
            "decision": "pass",
        }

    def run(self, docs: List[Document]) -> List[Dict[str, Any]]:
        return [self.run_one(doc) for doc in docs]
