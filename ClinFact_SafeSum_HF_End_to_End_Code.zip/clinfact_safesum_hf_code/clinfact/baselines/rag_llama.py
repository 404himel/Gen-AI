from typing import Any, Dict, List
from clinfact.config import ModelConfig, PipelineConfig
from clinfact.core.prompts import RAG_LLAMA_SUMMARY_PROMPT, SYSTEM_CLINICAL_SAFETY
from clinfact.core.retrieval import chunk_text, evidence_to_text, retrieve_evidence
from clinfact.core.schemas import Document
from clinfact.models.hf_generator import HFChatGenerator


class RAGLlamaBaseline:
    method_name = "Retrieval augmented Llama"

    def __init__(self, model_config: ModelConfig, pipeline_config: PipelineConfig):
        self.model_config = model_config
        self.pipeline_config = pipeline_config
        self.generator = HFChatGenerator(model_config.llama_model_id, model_config)

    def run_one(self, doc: Document) -> Dict[str, Any]:
        # Query the source with a generic clinical-summary intent and retrieve top chunks.
        query = "diagnosis medications allergies abnormal results procedures follow up clinical plan"
        chunks = retrieve_evidence(query, doc.source[: self.pipeline_config.max_source_chars], self.pipeline_config.top_k_evidence)
        prompt = RAG_LLAMA_SUMMARY_PROMPT.format(evidence=evidence_to_text(chunks))
        summary = self.generator.generate(prompt, system=SYSTEM_CLINICAL_SAFETY).strip()
        return {
            "doc_id": doc.doc_id,
            "method": self.method_name,
            "source": doc.source,
            "reference": doc.reference,
            "retrieved_evidence": chunks,
            "summary": summary,
            "delivered_output": summary,
            "decision": "pass",
        }

    def run(self, docs: List[Document]) -> List[Dict[str, Any]]:
        return [self.run_one(doc) for doc in docs]
