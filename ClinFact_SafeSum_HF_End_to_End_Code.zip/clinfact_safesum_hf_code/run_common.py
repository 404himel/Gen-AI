import argparse
import os
from typing import Tuple
from clinfact.config import ModelConfig, PipelineConfig


def add_common_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--data", required=True, help="Path to JSONL, JSON, or CSV data file.")
    parser.add_argument("--out", required=True, help="Output directory.")
    parser.add_argument("--phi_model_id", default="microsoft/Phi-3-mini-128k-instruct")
    parser.add_argument("--llama_model_id", default="meta-llama/Meta-Llama-3.1-8B-Instruct")
    parser.add_argument("--n_candidates", type=int, default=5)
    parser.add_argument("--alpha", type=float, default=0.60)
    parser.add_argument("--beta", type=float, default=0.40)
    parser.add_argument("--top_k_evidence", type=int, default=5)
    parser.add_argument("--h_max", type=int, default=1)
    parser.add_argument("--tau", type=float, default=0.90)
    parser.add_argument("--r_max", type=int, default=2)
    parser.add_argument("--max_source_chars", type=int, default=24000)
    parser.add_argument("--max_new_tokens", type=int, default=768)
    parser.add_argument("--temperature", type=float, default=0.2)
    parser.add_argument("--top_p", type=float, default=0.9)
    parser.add_argument("--do_sample", action="store_true")
    parser.add_argument("--load_in_4bit", action="store_true")
    parser.add_argument("--device_map", default="auto")
    parser.add_argument("--torch_dtype", default="auto", choices=["auto", "float16", "bfloat16"])
    parser.add_argument("--hf_token", default=None)
    parser.add_argument("--mock", action="store_true", help="Run deterministic mock mode without downloading HF models.")
    parser.add_argument("--compute_bert", action="store_true", help="Compute BERTScore if references exist. This can be slow.")


def build_configs(args) -> Tuple[ModelConfig, PipelineConfig]:
    model_config = ModelConfig(
        phi_model_id=args.phi_model_id,
        llama_model_id=args.llama_model_id,
        device_map=args.device_map,
        torch_dtype=args.torch_dtype,
        max_new_tokens=args.max_new_tokens,
        temperature=args.temperature,
        top_p=args.top_p,
        do_sample=args.do_sample,
        load_in_4bit=args.load_in_4bit,
        hf_token=args.hf_token or os.getenv("HF_TOKEN"),
        mock=args.mock,
    )
    pipeline_config = PipelineConfig(
        n_candidates=args.n_candidates,
        alpha=args.alpha,
        beta=args.beta,
        top_k_evidence=args.top_k_evidence,
        h_max=args.h_max,
        tau=args.tau,
        r_max=args.r_max,
        max_source_chars=args.max_source_chars,
    )
    return model_config, pipeline_config
